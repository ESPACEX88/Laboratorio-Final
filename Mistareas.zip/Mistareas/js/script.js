// Función para buscar tareas (Leer)
function searchTask() {
    const taskId = document.getElementById("searchTask").value;
    if (taskId) {
        alert(`Buscando la tarea con ID: ${taskId}`);
        // Aquí puedes agregar la lógica para conectar con la API y obtener la tarea
        fetch(`https://tu-api.com/tareas/${taskId}`) // Cambia la URL por la de tu API
            .then(response => {
                if (!response.ok) {
                    throw new Error('No se encontró la tarea');
                }
                return response.json();
            })
            .then(data => {
                // Maneja los datos de la tarea aquí
                console.log(data);
                alert(`Tarea encontrada: ${JSON.stringify(data)}`);
            })
            .catch(error => {
                alert(`Error: ${error.message}`);
            });
    } else {
        alert("Por favor, ingresa un ID de tarea.");
    }
}

// Función para crear una nueva tarea
function createTask() {
    const taskName = document.getElementById("newTaskName").value;
    const taskDescription = document.getElementById("newTaskDescription").value;

    if (taskName && taskDescription) {
        alert(`Creando tarea: ${taskName}`);
        
        // Lógica para enviar los datos a la API y crear la tarea
        fetch('https://tu-api.com/tareas', { // Cambia la URL por la de tu API
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: taskName,
                description: taskDescription
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la creación de la tarea');
            }
            return response.json();
        })
        .then(data => {
            // Maneja la respuesta de la API aquí
            console.log(data);
            alert('Tarea creada exitosamente.');
            // Redirige al menú principal después de crear la tarea
            window.location.href = "menu_principal.html"; // Cambia esto por la URL de tu menú principal
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });

    } else {
        alert("Por favor, completa todos los campos.");
    }
}

// Función para actualizar una tarea existente
function updateTask() {
    const taskId = document.getElementById("taskId").value;
    const taskName = document.getElementById("taskName").value;
    const taskDescription = document.getElementById("taskDescription").value;

    if (taskId && taskName && taskDescription) {
        alert(`Actualizando la tarea con ID: ${taskId}`);
        
        // Lógica para actualizar la tarea en la API
        fetch(`https://tu-api.com/tareas/${taskId}`, { // Cambia la URL por la de tu API
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: taskName,
                description: taskDescription
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar la tarea');
            }
            return response.json();
        })
        .then(data => {
            // Maneja la respuesta de la API aquí
            console.log(data);
            alert('Tarea actualizada exitosamente.');
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });
    } else {
        alert("Por favor, completa todos los campos.");
    }
}

// Función para eliminar una tarea
function deleteTask() {
    const taskId = document.getElementById("deleteTaskId").value;
    if (taskId) {
        alert(`Eliminando la tarea con ID: ${taskId}`);
        
        // Lógica para eliminar la tarea de la API
        fetch(`https://tu-api.com/tareas/${taskId}`, { // Cambia la URL por la de tu API
            method: 'DELETE'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al eliminar la tarea');
            }
            alert('Tarea eliminada exitosamente.');
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });
    } else {
        alert("Por favor, ingresa un ID de tarea para eliminar.");
    }
}
